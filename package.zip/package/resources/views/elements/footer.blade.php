<div class="footer">
	<div class="copyright">
		<p>Copyright © Designed &amp; Developed by <a href="https://dexignlab.com/" target="_blank">DexignLab</a> 2024</p>
	</div>
</div>