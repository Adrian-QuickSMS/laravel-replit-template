@extends('layouts.default')
@section('content')
<div class="container-fluid">
				
</div>
@endsection	