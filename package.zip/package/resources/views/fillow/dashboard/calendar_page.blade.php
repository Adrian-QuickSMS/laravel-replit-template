@extends('layouts.default')
@section('content')
<div class="container-fluid">
	<div class="row">
		<div class="col-xl-12">
			<div class="card">
				<div class="card-body">
					<div id="calendar" class="fullcalendar"></div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection